/* Codded by @phaticusthiccy
Telegram: t.me/phaticusthiccy
Instagram: www.instagram.com/kyrie.baran
*/

const Asena = require('../events');
const {MessageType, MessageOptions, Mimetype} = require('@adiwajshing/baileys');
const Heroku = require('heroku-client');
const Config = require('../config');

const Language = require('../language');
const Lang = Language.getString('spammer');

const heroku = new Heroku({
    token: Config.HEROKU.API_KEY
});


let baseURI = '/apps/' + Config.HEROKU.APP_NAME;


Asena.addCommand({pattern: 'spam ?(.*)', fromMe: true, desc: Lang.SPAM_DESC}, (async (message, match) => {

    if (match[1] === '') {

        return await message.sendMessage(Lang.NEED_WORD);

    }

    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);

    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);
    
    await message.sendMessage(`${match[1]}`);

}));

Asena.addCommand({pattern: 'sstop', fromMe: true, desc: Lang.STOP_SPAMDESC}, (async (message, match) => {

    await message.sendMessage(Lang.STOP_SPAM);

    console.log(baseURI);
    await heroku.delete(baseURI + '/dynos').catch(async (error) => {
        await message.sendMessage(error.message);

    });
}));
